﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMainMenu))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.RegistrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalesmanToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SupplierToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QuotationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VoucherToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProductToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServiceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StockInToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BillingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProductsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProductsRepairToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PaymentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DatabaseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem17 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SqlServerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SendSMSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem18 = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.MasterEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CompanyInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CategoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SubCategoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem9 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem10 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProductsToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServiceToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem11 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem12 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalesmanToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalesmanToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SuppliersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProductsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PurchasesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServicesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QuotationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServiceBillingToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PaymentsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PaymentsToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem13 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem14 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem15 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SMSToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SQLServerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalesReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServiceBillingReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StockInAndStockOutReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PurchaseReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExpenditureReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CreditorsAndDebtorsReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProfitAndLossReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DayBookToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PurchaseDaybookToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.GeneralDaybookToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SupplierLedgerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomerLedgerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.GeneralLedgerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalesmanLedgerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem16 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalesmanCommissionToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CreditTermsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CreditTermsStatementsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.TaxToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.OverallToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CalculatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NotepadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WordpadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MSWordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TaskManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SystemInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblUserType = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblUser = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblDateTime = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblTime = New System.Windows.Forms.ToolStripStatusLabel()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1.SuspendLayout()
        Me.MenuStrip2.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegistrationToolStripMenuItem, Me.CustomerToolStripMenuItem, Me.SalesmanToolStripMenuItem3, Me.SupplierToolStripMenuItem, Me.QuotationToolStripMenuItem, Me.VoucherToolStripMenuItem, Me.ProductToolStripMenuItem, Me.StockToolStripMenuItem, Me.ServiceToolStripMenuItem, Me.StockInToolStripMenuItem, Me.BillingToolStripMenuItem, Me.PaymentToolStripMenuItem, Me.DatabaseToolStripMenuItem, Me.ToolStripMenuItem1, Me.LogsToolStripMenuItem, Me.ToolStripMenuItem17, Me.SendSMSToolStripMenuItem, Me.ToolStripMenuItem18, Me.LogoutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 26)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1362, 76)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'RegistrationToolStripMenuItem
        '
        Me.RegistrationToolStripMenuItem.Image = Global.Sales_and_Inventory_System.My.Resources.Resources.images__3__3
        Me.RegistrationToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RegistrationToolStripMenuItem.Name = "RegistrationToolStripMenuItem"
        Me.RegistrationToolStripMenuItem.Size = New System.Drawing.Size(94, 72)
        Me.RegistrationToolStripMenuItem.Text = "Registration"
        Me.RegistrationToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'CustomerToolStripMenuItem
        '
        Me.CustomerToolStripMenuItem.Image = Global.Sales_and_Inventory_System.My.Resources.Resources.images__16_
        Me.CustomerToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.CustomerToolStripMenuItem.Name = "CustomerToolStripMenuItem"
        Me.CustomerToolStripMenuItem.Size = New System.Drawing.Size(79, 72)
        Me.CustomerToolStripMenuItem.Text = "Customer"
        Me.CustomerToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'SalesmanToolStripMenuItem3
        '
        Me.SalesmanToolStripMenuItem3.Image = Global.Sales_and_Inventory_System.My.Resources.Resources.download__7_
        Me.SalesmanToolStripMenuItem3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.SalesmanToolStripMenuItem3.Name = "SalesmanToolStripMenuItem3"
        Me.SalesmanToolStripMenuItem3.Size = New System.Drawing.Size(79, 72)
        Me.SalesmanToolStripMenuItem3.Text = "Salesman"
        Me.SalesmanToolStripMenuItem3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'SupplierToolStripMenuItem
        '
        Me.SupplierToolStripMenuItem.Image = Global.Sales_and_Inventory_System.My.Resources.Resources.supplier_icon_300x300_1
        Me.SupplierToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.SupplierToolStripMenuItem.Name = "SupplierToolStripMenuItem"
        Me.SupplierToolStripMenuItem.Size = New System.Drawing.Size(72, 72)
        Me.SupplierToolStripMenuItem.Text = "Supplier"
        Me.SupplierToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'QuotationToolStripMenuItem
        '
        Me.QuotationToolStripMenuItem.Image = Global.Sales_and_Inventory_System.My.Resources.Resources.download__4_
        Me.QuotationToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.QuotationToolStripMenuItem.Name = "QuotationToolStripMenuItem"
        Me.QuotationToolStripMenuItem.Size = New System.Drawing.Size(82, 72)
        Me.QuotationToolStripMenuItem.Text = "Quotation"
        Me.QuotationToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'VoucherToolStripMenuItem
        '
        Me.VoucherToolStripMenuItem.Image = Global.Sales_and_Inventory_System.My.Resources.Resources.zanox_icon_voucher_162x162
        Me.VoucherToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.VoucherToolStripMenuItem.Name = "VoucherToolStripMenuItem"
        Me.VoucherToolStripMenuItem.Size = New System.Drawing.Size(78, 72)
        Me.VoucherToolStripMenuItem.Text = "Vouchers"
        Me.VoucherToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ProductToolStripMenuItem
        '
        Me.ProductToolStripMenuItem.Image = Global.Sales_and_Inventory_System.My.Resources.Resources.download__3_
        Me.ProductToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ProductToolStripMenuItem.Name = "ProductToolStripMenuItem"
        Me.ProductToolStripMenuItem.Size = New System.Drawing.Size(73, 72)
        Me.ProductToolStripMenuItem.Text = "Products"
        Me.ProductToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'StockToolStripMenuItem
        '
        Me.StockToolStripMenuItem.Image = Global.Sales_and_Inventory_System.My.Resources.Resources.download__1_
        Me.StockToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.StockToolStripMenuItem.Name = "StockToolStripMenuItem"
        Me.StockToolStripMenuItem.Size = New System.Drawing.Size(75, 72)
        Me.StockToolStripMenuItem.Text = "Purchase"
        Me.StockToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ServiceToolStripMenuItem
        '
        Me.ServiceToolStripMenuItem.Image = Global.Sales_and_Inventory_System.My.Resources.Resources.investment_icon__Original_Size_
        Me.ServiceToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ServiceToolStripMenuItem.Name = "ServiceToolStripMenuItem"
        Me.ServiceToolStripMenuItem.Size = New System.Drawing.Size(62, 72)
        Me.ServiceToolStripMenuItem.Text = "Stock "
        Me.ServiceToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'StockInToolStripMenuItem
        '
        Me.StockInToolStripMenuItem.Image = Global.Sales_and_Inventory_System.My.Resources.Resources.download__2_
        Me.StockInToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.StockInToolStripMenuItem.Name = "StockInToolStripMenuItem"
        Me.StockInToolStripMenuItem.Size = New System.Drawing.Size(70, 72)
        Me.StockInToolStripMenuItem.Text = "Services"
        Me.StockInToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'BillingToolStripMenuItem
        '
        Me.BillingToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProductsToolStripMenuItem, Me.ProductsRepairToolStripMenuItem})
        Me.BillingToolStripMenuItem.Image = Global.Sales_and_Inventory_System.My.Resources.Resources.download
        Me.BillingToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.BillingToolStripMenuItem.Name = "BillingToolStripMenuItem"
        Me.BillingToolStripMenuItem.Size = New System.Drawing.Size(62, 72)
        Me.BillingToolStripMenuItem.Text = "Sales"
        Me.BillingToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ProductsToolStripMenuItem
        '
        Me.ProductsToolStripMenuItem.Name = "ProductsToolStripMenuItem"
        Me.ProductsToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.ProductsToolStripMenuItem.Text = "Products Sales"
        '
        'ProductsRepairToolStripMenuItem
        '
        Me.ProductsRepairToolStripMenuItem.Name = "ProductsRepairToolStripMenuItem"
        Me.ProductsRepairToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.ProductsRepairToolStripMenuItem.Text = "Service Invoice"
        '
        'PaymentToolStripMenuItem
        '
        Me.PaymentToolStripMenuItem.Image = Global.Sales_and_Inventory_System.My.Resources.Resources.images__5_1
        Me.PaymentToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.PaymentToolStripMenuItem.Name = "PaymentToolStripMenuItem"
        Me.PaymentToolStripMenuItem.Size = New System.Drawing.Size(73, 72)
        Me.PaymentToolStripMenuItem.Text = "Payment"
        Me.PaymentToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'DatabaseToolStripMenuItem
        '
        Me.DatabaseToolStripMenuItem.Image = CType(resources.GetObject("DatabaseToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DatabaseToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.DatabaseToolStripMenuItem.Name = "DatabaseToolStripMenuItem"
        Me.DatabaseToolStripMenuItem.Size = New System.Drawing.Size(77, 72)
        Me.DatabaseToolStripMenuItem.Text = "Database"
        Me.DatabaseToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Image = Global.Sales_and_Inventory_System.My.Resources.Resources.Recovery
        Me.ToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(66, 72)
        Me.ToolStripMenuItem1.Text = "Restore"
        Me.ToolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'LogsToolStripMenuItem
        '
        Me.LogsToolStripMenuItem.Image = Global.Sales_and_Inventory_System.My.Resources.Resources.log_icon
        Me.LogsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.LogsToolStripMenuItem.Name = "LogsToolStripMenuItem"
        Me.LogsToolStripMenuItem.Size = New System.Drawing.Size(60, 72)
        Me.LogsToolStripMenuItem.Text = "Logs"
        Me.LogsToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripMenuItem17
        '
        Me.ToolStripMenuItem17.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SqlServerToolStripMenuItem1})
        Me.ToolStripMenuItem17.Image = Global.Sales_and_Inventory_System.My.Resources.Resources.Setting_icon_1
        Me.ToolStripMenuItem17.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripMenuItem17.Name = "ToolStripMenuItem17"
        Me.ToolStripMenuItem17.Size = New System.Drawing.Size(63, 72)
        Me.ToolStripMenuItem17.Text = "Setting"
        Me.ToolStripMenuItem17.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'SqlServerToolStripMenuItem1
        '
        Me.SqlServerToolStripMenuItem1.Name = "SqlServerToolStripMenuItem1"
        Me.SqlServerToolStripMenuItem1.Size = New System.Drawing.Size(145, 22)
        Me.SqlServerToolStripMenuItem1.Text = "SQL Server"
        '
        'SendSMSToolStripMenuItem
        '
        Me.SendSMSToolStripMenuItem.Image = Global.Sales_and_Inventory_System.My.Resources.Resources.download__5_
        Me.SendSMSToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.SendSMSToolStripMenuItem.Name = "SendSMSToolStripMenuItem"
        Me.SendSMSToolStripMenuItem.Size = New System.Drawing.Size(62, 72)
        Me.SendSMSToolStripMenuItem.Text = "SMS"
        Me.SendSMSToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripMenuItem18
        '
        Me.ToolStripMenuItem18.Image = Global.Sales_and_Inventory_System.My.Resources.Resources.images__13_
        Me.ToolStripMenuItem18.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripMenuItem18.Name = "ToolStripMenuItem18"
        Me.ToolStripMenuItem18.Size = New System.Drawing.Size(62, 72)
        Me.ToolStripMenuItem18.Text = "Help.."
        Me.ToolStripMenuItem18.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Image = Global.Sales_and_Inventory_System.My.Resources.Resources.download__9_
        Me.LogoutToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(64, 72)
        Me.LogoutToolStripMenuItem.Text = "Logout"
        Me.LogoutToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'MenuStrip2
        '
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MasterEntryToolStripMenuItem, Me.ToolStripMenuItem2, Me.ToolStripMenuItem3, Me.ToolStripMenuItem4, Me.ToolStripMenuItem5, Me.ToolStripMenuItem6, Me.ToolStripMenuItem7, Me.ToolStripMenuItem8, Me.ToolStripMenuItem9, Me.ToolStripMenuItem10, Me.ToolStripMenuItem11, Me.ToolStripMenuItem12, Me.ToolStripMenuItem13, Me.ToolStripMenuItem14, Me.ToolStripMenuItem15, Me.ToolsToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogoutToolStripMenuItem1})
        Me.MenuStrip2.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(1362, 26)
        Me.MenuStrip2.TabIndex = 1
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'MasterEntryToolStripMenuItem
        '
        Me.MasterEntryToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CompanyInfoToolStripMenuItem, Me.ContactsToolStripMenuItem, Me.CategoryToolStripMenuItem, Me.SubCategoryToolStripMenuItem})
        Me.MasterEntryToolStripMenuItem.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MasterEntryToolStripMenuItem.Name = "MasterEntryToolStripMenuItem"
        Me.MasterEntryToolStripMenuItem.Size = New System.Drawing.Size(97, 22)
        Me.MasterEntryToolStripMenuItem.Text = "Master Entry"
        '
        'CompanyInfoToolStripMenuItem
        '
        Me.CompanyInfoToolStripMenuItem.Name = "CompanyInfoToolStripMenuItem"
        Me.CompanyInfoToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.CompanyInfoToolStripMenuItem.Text = "Company Info"
        '
        'ContactsToolStripMenuItem
        '
        Me.ContactsToolStripMenuItem.Name = "ContactsToolStripMenuItem"
        Me.ContactsToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.ContactsToolStripMenuItem.Text = "Contacts"
        '
        'CategoryToolStripMenuItem
        '
        Me.CategoryToolStripMenuItem.Name = "CategoryToolStripMenuItem"
        Me.CategoryToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.CategoryToolStripMenuItem.Text = "Category"
        '
        'SubCategoryToolStripMenuItem
        '
        Me.SubCategoryToolStripMenuItem.Name = "SubCategoryToolStripMenuItem"
        Me.SubCategoryToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.SubCategoryToolStripMenuItem.Text = "Sub Category"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(94, 22)
        Me.ToolStripMenuItem2.Text = "Registration"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(85, 22)
        Me.ToolStripMenuItem3.Text = "Customers"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(74, 22)
        Me.ToolStripMenuItem4.Text = "Supplers"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(83, 22)
        Me.ToolStripMenuItem5.Text = "Sales Man"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(73, 22)
        Me.ToolStripMenuItem6.Text = "Products"
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(78, 22)
        Me.ToolStripMenuItem7.Text = "Purchase "
        '
        'ToolStripMenuItem8
        '
        Me.ToolStripMenuItem8.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem8.Name = "ToolStripMenuItem8"
        Me.ToolStripMenuItem8.Size = New System.Drawing.Size(122, 22)
        Me.ToolStripMenuItem8.Text = "Inventory Stocks"
        '
        'ToolStripMenuItem9
        '
        Me.ToolStripMenuItem9.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem9.Name = "ToolStripMenuItem9"
        Me.ToolStripMenuItem9.Size = New System.Drawing.Size(70, 22)
        Me.ToolStripMenuItem9.Text = "Services"
        '
        'ToolStripMenuItem10
        '
        Me.ToolStripMenuItem10.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProductsToolStripMenuItem2, Me.ServiceToolStripMenuItem1})
        Me.ToolStripMenuItem10.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem10.Name = "ToolStripMenuItem10"
        Me.ToolStripMenuItem10.Size = New System.Drawing.Size(67, 22)
        Me.ToolStripMenuItem10.Text = "Billings"
        '
        'ProductsToolStripMenuItem2
        '
        Me.ProductsToolStripMenuItem2.Name = "ProductsToolStripMenuItem2"
        Me.ProductsToolStripMenuItem2.Size = New System.Drawing.Size(68, 22)
        '
        'ServiceToolStripMenuItem1
        '
        Me.ServiceToolStripMenuItem1.Name = "ServiceToolStripMenuItem1"
        Me.ServiceToolStripMenuItem1.Size = New System.Drawing.Size(68, 22)
        '
        'ToolStripMenuItem11
        '
        Me.ToolStripMenuItem11.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem11.Name = "ToolStripMenuItem11"
        Me.ToolStripMenuItem11.Size = New System.Drawing.Size(76, 22)
        Me.ToolStripMenuItem11.Text = "Payment "
        '
        'ToolStripMenuItem12
        '
        Me.ToolStripMenuItem12.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CustomersToolStripMenuItem, Me.SalesmanToolStripMenuItem4, Me.SalesmanToolStripMenuItem5, Me.SuppliersToolStripMenuItem, Me.ProductsToolStripMenuItem1, Me.PurchasesToolStripMenuItem, Me.ServicesToolStripMenuItem, Me.QuotationsToolStripMenuItem, Me.ServiceBillingToolStripMenuItem1, Me.PaymentsToolStripMenuItem1, Me.PaymentsToolStripMenuItem2})
        Me.ToolStripMenuItem12.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem12.Name = "ToolStripMenuItem12"
        Me.ToolStripMenuItem12.Size = New System.Drawing.Size(72, 22)
        Me.ToolStripMenuItem12.Text = "Records "
        '
        'CustomersToolStripMenuItem
        '
        Me.CustomersToolStripMenuItem.Name = "CustomersToolStripMenuItem"
        Me.CustomersToolStripMenuItem.Size = New System.Drawing.Size(68, 22)
        '
        'SalesmanToolStripMenuItem4
        '
        Me.SalesmanToolStripMenuItem4.Name = "SalesmanToolStripMenuItem4"
        Me.SalesmanToolStripMenuItem4.Size = New System.Drawing.Size(68, 22)
        '
        'SalesmanToolStripMenuItem5
        '
        Me.SalesmanToolStripMenuItem5.Name = "SalesmanToolStripMenuItem5"
        Me.SalesmanToolStripMenuItem5.Size = New System.Drawing.Size(68, 22)
        '
        'SuppliersToolStripMenuItem
        '
        Me.SuppliersToolStripMenuItem.Name = "SuppliersToolStripMenuItem"
        Me.SuppliersToolStripMenuItem.Size = New System.Drawing.Size(68, 22)
        '
        'ProductsToolStripMenuItem1
        '
        Me.ProductsToolStripMenuItem1.Name = "ProductsToolStripMenuItem1"
        Me.ProductsToolStripMenuItem1.Size = New System.Drawing.Size(68, 22)
        '
        'PurchasesToolStripMenuItem
        '
        Me.PurchasesToolStripMenuItem.Name = "PurchasesToolStripMenuItem"
        Me.PurchasesToolStripMenuItem.Size = New System.Drawing.Size(68, 22)
        '
        'ServicesToolStripMenuItem
        '
        Me.ServicesToolStripMenuItem.Name = "ServicesToolStripMenuItem"
        Me.ServicesToolStripMenuItem.Size = New System.Drawing.Size(68, 22)
        '
        'QuotationsToolStripMenuItem
        '
        Me.QuotationsToolStripMenuItem.Name = "QuotationsToolStripMenuItem"
        Me.QuotationsToolStripMenuItem.Size = New System.Drawing.Size(68, 22)
        '
        'ServiceBillingToolStripMenuItem1
        '
        Me.ServiceBillingToolStripMenuItem1.Name = "ServiceBillingToolStripMenuItem1"
        Me.ServiceBillingToolStripMenuItem1.Size = New System.Drawing.Size(68, 22)
        '
        'PaymentsToolStripMenuItem1
        '
        Me.PaymentsToolStripMenuItem1.Name = "PaymentsToolStripMenuItem1"
        Me.PaymentsToolStripMenuItem1.Size = New System.Drawing.Size(68, 22)
        '
        'PaymentsToolStripMenuItem2
        '
        Me.PaymentsToolStripMenuItem2.Name = "PaymentsToolStripMenuItem2"
        Me.PaymentsToolStripMenuItem2.Size = New System.Drawing.Size(68, 22)
        '
        'ToolStripMenuItem13
        '
        Me.ToolStripMenuItem13.Name = "ToolStripMenuItem13"
        Me.ToolStripMenuItem13.Size = New System.Drawing.Size(12, 22)
        '
        'ToolStripMenuItem14
        '
        Me.ToolStripMenuItem14.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem14.Name = "ToolStripMenuItem14"
        Me.ToolStripMenuItem14.Size = New System.Drawing.Size(50, 22)
        Me.ToolStripMenuItem14.Text = "Logs"
        '
        'ToolStripMenuItem15
        '
        Me.ToolStripMenuItem15.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SMSToolStripMenuItem1, Me.SQLServerToolStripMenuItem})
        Me.ToolStripMenuItem15.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem15.Name = "ToolStripMenuItem15"
        Me.ToolStripMenuItem15.Size = New System.Drawing.Size(63, 22)
        Me.ToolStripMenuItem15.Text = "Setting"
        '
        'SMSToolStripMenuItem1
        '
        Me.SMSToolStripMenuItem1.Name = "SMSToolStripMenuItem1"
        Me.SMSToolStripMenuItem1.Size = New System.Drawing.Size(68, 22)
        '
        'SQLServerToolStripMenuItem
        '
        Me.SQLServerToolStripMenuItem.Name = "SQLServerToolStripMenuItem"
        Me.SQLServerToolStripMenuItem.Size = New System.Drawing.Size(68, 22)
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(12, 22)
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(61, 22)
        Me.AboutToolStripMenuItem.Text = "About "
        '
        'LogoutToolStripMenuItem1
        '
        Me.LogoutToolStripMenuItem1.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogoutToolStripMenuItem1.Name = "LogoutToolStripMenuItem1"
        Me.LogoutToolStripMenuItem1.Size = New System.Drawing.Size(64, 22)
        Me.LogoutToolStripMenuItem1.Text = "Logout"
        '
        'SalesReportToolStripMenuItem
        '
        Me.SalesReportToolStripMenuItem.Name = "SalesReportToolStripMenuItem"
        Me.SalesReportToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        '
        'ServiceBillingReportToolStripMenuItem
        '
        Me.ServiceBillingReportToolStripMenuItem.Name = "ServiceBillingReportToolStripMenuItem"
        Me.ServiceBillingReportToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        '
        'StockInAndStockOutReportToolStripMenuItem
        '
        Me.StockInAndStockOutReportToolStripMenuItem.Name = "StockInAndStockOutReportToolStripMenuItem"
        Me.StockInAndStockOutReportToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        '
        'PurchaseReportToolStripMenuItem
        '
        Me.PurchaseReportToolStripMenuItem.Name = "PurchaseReportToolStripMenuItem"
        Me.PurchaseReportToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        '
        'ExpenditureReportToolStripMenuItem
        '
        Me.ExpenditureReportToolStripMenuItem.Name = "ExpenditureReportToolStripMenuItem"
        Me.ExpenditureReportToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        '
        'CreditorsAndDebtorsReportsToolStripMenuItem
        '
        Me.CreditorsAndDebtorsReportsToolStripMenuItem.Name = "CreditorsAndDebtorsReportsToolStripMenuItem"
        Me.CreditorsAndDebtorsReportsToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        '
        'ProfitAndLossReportsToolStripMenuItem
        '
        Me.ProfitAndLossReportsToolStripMenuItem.Name = "ProfitAndLossReportsToolStripMenuItem"
        Me.ProfitAndLossReportsToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        '
        'DayBookToolStripMenuItem1
        '
        Me.DayBookToolStripMenuItem1.Name = "DayBookToolStripMenuItem1"
        Me.DayBookToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        '
        'PurchaseDaybookToolStripMenuItem1
        '
        Me.PurchaseDaybookToolStripMenuItem1.Name = "PurchaseDaybookToolStripMenuItem1"
        Me.PurchaseDaybookToolStripMenuItem1.Size = New System.Drawing.Size(191, 22)
        Me.PurchaseDaybookToolStripMenuItem1.Text = "Purchase Daybook"
        '
        'GeneralDaybookToolStripMenuItem1
        '
        Me.GeneralDaybookToolStripMenuItem1.Name = "GeneralDaybookToolStripMenuItem1"
        Me.GeneralDaybookToolStripMenuItem1.Size = New System.Drawing.Size(191, 22)
        Me.GeneralDaybookToolStripMenuItem1.Text = "General Daybook"
        '
        'SupplierLedgerToolStripMenuItem1
        '
        Me.SupplierLedgerToolStripMenuItem1.Name = "SupplierLedgerToolStripMenuItem1"
        Me.SupplierLedgerToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        '
        'CustomerLedgerToolStripMenuItem1
        '
        Me.CustomerLedgerToolStripMenuItem1.Name = "CustomerLedgerToolStripMenuItem1"
        Me.CustomerLedgerToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        '
        'GeneralLedgerToolStripMenuItem1
        '
        Me.GeneralLedgerToolStripMenuItem1.Name = "GeneralLedgerToolStripMenuItem1"
        Me.GeneralLedgerToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        '
        'SalesmanLedgerToolStripMenuItem1
        '
        Me.SalesmanLedgerToolStripMenuItem1.Name = "SalesmanLedgerToolStripMenuItem1"
        Me.SalesmanLedgerToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        '
        'ToolStripMenuItem16
        '
        Me.ToolStripMenuItem16.Name = "ToolStripMenuItem16"
        Me.ToolStripMenuItem16.Size = New System.Drawing.Size(32, 19)
        '
        'SalesmanCommissionToolStripMenuItem1
        '
        Me.SalesmanCommissionToolStripMenuItem1.Name = "SalesmanCommissionToolStripMenuItem1"
        Me.SalesmanCommissionToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        '
        'CreditTermsToolStripMenuItem1
        '
        Me.CreditTermsToolStripMenuItem1.Name = "CreditTermsToolStripMenuItem1"
        Me.CreditTermsToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        '
        'CreditTermsStatementsToolStripMenuItem1
        '
        Me.CreditTermsStatementsToolStripMenuItem1.Name = "CreditTermsStatementsToolStripMenuItem1"
        Me.CreditTermsStatementsToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        '
        'TaxToolStripMenuItem1
        '
        Me.TaxToolStripMenuItem1.Name = "TaxToolStripMenuItem1"
        Me.TaxToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        '
        'OverallToolStripMenuItem1
        '
        Me.OverallToolStripMenuItem1.Name = "OverallToolStripMenuItem1"
        Me.OverallToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        '
        'CalculatorToolStripMenuItem
        '
        Me.CalculatorToolStripMenuItem.Name = "CalculatorToolStripMenuItem"
        Me.CalculatorToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        '
        'NotepadToolStripMenuItem
        '
        Me.NotepadToolStripMenuItem.Name = "NotepadToolStripMenuItem"
        Me.NotepadToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        '
        'WordpadToolStripMenuItem
        '
        Me.WordpadToolStripMenuItem.Name = "WordpadToolStripMenuItem"
        Me.WordpadToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        '
        'MSWordToolStripMenuItem
        '
        Me.MSWordToolStripMenuItem.Name = "MSWordToolStripMenuItem"
        Me.MSWordToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        '
        'TaskManagerToolStripMenuItem
        '
        Me.TaskManagerToolStripMenuItem.Name = "TaskManagerToolStripMenuItem"
        Me.TaskManagerToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        '
        'SystemInfoToolStripMenuItem
        '
        Me.SystemInfoToolStripMenuItem.Name = "SystemInfoToolStripMenuItem"
        Me.SystemInfoToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.lblUserType, Me.ToolStripStatusLabel2, Me.lblUser, Me.ToolStripStatusLabel3, Me.lblDateTime, Me.lblTime})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 627)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1362, 23)
        Me.StatusStrip1.TabIndex = 6
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel1.ForeColor = System.Drawing.Color.Crimson
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(96, 18)
        Me.ToolStripStatusLabel1.Text = "Logged in As :"
        '
        'lblUserType
        '
        Me.lblUserType.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUserType.ForeColor = System.Drawing.Color.Maroon
        Me.lblUserType.Image = CType(resources.GetObject("lblUserType.Image"), System.Drawing.Image)
        Me.lblUserType.Name = "lblUserType"
        Me.lblUserType.Size = New System.Drawing.Size(86, 18)
        Me.lblUserType.Text = "User Type"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(11, 18)
        Me.ToolStripStatusLabel2.Text = ":"
        '
        'lblUser
        '
        Me.lblUser.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUser.ForeColor = System.Drawing.Color.Indigo
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(76, 18)
        Me.lblUser.Text = "User Name"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(950, 18)
        Me.ToolStripStatusLabel3.Spring = True
        '
        'lblDateTime
        '
        Me.lblDateTime.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateTime.ForeColor = System.Drawing.Color.Maroon
        Me.lblDateTime.Image = CType(resources.GetObject("lblDateTime.Image"), System.Drawing.Image)
        Me.lblDateTime.Name = "lblDateTime"
        Me.lblDateTime.Size = New System.Drawing.Size(88, 18)
        Me.lblDateTime.Text = "Date Time"
        '
        'lblTime
        '
        Me.lblTime.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTime.ForeColor = System.Drawing.Color.DarkMagenta
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(40, 18)
        Me.lblTime.Text = "Time"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'Timer2
        '
        '
        'frmMainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1362, 650)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.MenuStrip2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMainMenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Main Menu"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents RegistrationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip2 As System.Windows.Forms.MenuStrip
    Friend WithEvents MasterEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SupplierToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProductToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StockToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BillingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DatabaseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CalculatorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NotepadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WordpadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MSWordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TaskManagerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SystemInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblUserType As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblUser As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblDateTime As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents CompanyInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CategoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SubCategoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StockInToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContactsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ServiceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents QuotationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProductsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProductsRepairToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblTime As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents VoucherToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PaymentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalesmanToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SendSMSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem7 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem8 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem9 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem10 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem11 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem12 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem13 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem14 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem15 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SMSToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SQLServerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalesmanToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SuppliersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProductsToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PurchasesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ServicesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents QuotationsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ServiceBillingToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PaymentsToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PaymentsToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalesmanToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalesReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ServiceBillingReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StockInAndStockOutReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PurchaseReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExpenditureReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreditorsAndDebtorsReportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProfitAndLossReportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DayBookToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SupplierLedgerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerLedgerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GeneralLedgerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalesmanLedgerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalesmanCommissionToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreditTermsToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreditTermsStatementsToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TaxToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OverallToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PurchaseDaybookToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GeneralDaybookToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem16 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem17 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem18 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProductsToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ServiceToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SqlServerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
End Class
